from flask import Flask, url_for,request,render_template,redirect
from werkzeug.utils import secure_filename
import os
#from io import BytesIO
import base64
#import re
#import json


app = Flask(__name__)

@app.route('/')  
def index():
    return render_template('upload.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
		if request.method == 'POST':
			#f = request.files['the_file']
			#f.save('static/' + secure_filename(f.filename))
			#f.save('static/' + f.filename)
			f = open("static/"+request.form['img_name'],"wb")
			f.write(base64.b64decode(request.form['img_data']))
			#f.write(request.form['img_data'])
			f.close()
			return '''Uploaded successfully!!!!'''
			#redirect(url_for('index'))
		return '''No sucess'''   


@app.route('/read')
def read_file():			
		f = open("static/tender_585147.jpg","r")
		if f.mode == 'r':
			contents  = f.read()
		#print(contents )
		#f.close()
		return '''Uploaded successfully!!!!'''
		#redirect(url_for('index'))
@app.route('/list')  
def list():
	BASE_DIR = 'static/'

	# Joining the base and the requested path
	abs_path = os.path.join(BASE_DIR, '')
	#

	# Return 404 if path doesn't exist
	if not os.path.exists(abs_path):
		return abort(404)

	# Check if path is a file and serve
	if os.path.isfile(abs_path):
		return send_file(abs_path)

	# Show directory contents
	files = os.listdir(abs_path)
	print(files)
	return render_template('list.html', files=files)



if __name__ == "__main__":
	app.run()
